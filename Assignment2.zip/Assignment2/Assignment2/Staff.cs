﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Assignment2
{
    public class Staff
    {
        public string First { get; set; }
        public string Last { get; set; }
        public int ID { get; set; }
    }
}
