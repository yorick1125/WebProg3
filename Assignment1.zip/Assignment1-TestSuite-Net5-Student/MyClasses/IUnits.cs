﻿/*
* Course: 		Web Programming 3
* Assessment: 	Assignment 1
* Created by: 	Yorick-Ntwari Niyonkuru
* Date: 		10 September 2022
* Class Name: 	IUnits.cs
* Description: 	Interface for all housing elements.
    */

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment1
{
    public interface IUnits
    {
        public decimal ProjectedRentalAmt();

    }
}
